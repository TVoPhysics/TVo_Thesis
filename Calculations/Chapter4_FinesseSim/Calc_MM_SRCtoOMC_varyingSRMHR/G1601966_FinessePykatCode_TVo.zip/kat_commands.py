#Commands to get QM-lim sensitivity
darm_commands = """
tf sus 1 0 p $mech_fres $mech_Q
const mech_fres 1  # Approx. resonance frequency
const mech_Q    1M # Guess for suspension Q factor
# Differentially modulate the strain in the arms
fsig darm  LXarm 1 0 1
fsig darm2 LYarm 1 180 1
qnoisedS NSR_with_RP 1 $fs nOMC_AROC_trans
xaxis darm f log 5 5k 50
yaxis lin re:im
retrace off
"""

commands = """
tf sus 1 0 p $mech_fres $mech_Q
const mech_fres 1  # Approx. resonance frequency
const mech_Q    1M # Guess for suspension Q factor
# Differentially modulate the strain in the arms
fsig darm  LXarm 1 0 1
fsig darm2 LYarm 1 180 1
#qnoisedS NSR_with_RP 1 $fs nOMC_AROC_trans
#xaxis darm f log 5 5k 50
yaxis lin re:im
noxaxis
retrace off
"""
###Add amplitude detectors to get Higher-Order mordal content within the cavity at the carrier freq
amplitude_detectors = """
ad nSRMHRaTEM00 0 0 0 nSRMHRa
ad nSRMHRaTEM01 0 1 0 nSRMHRa
ad nSRMHRaTEM02 0 2 0 nSRMHRa
#ad nSRMHRaTEM03 0 3 0 nSRMHRa
#ad nSRMHRaTEM04 0 4 0 nSRMHRa
"""
###Add photodetectors to get gaussian beam parameters right outside of SRC after the anti-thermal lens correction
pds = """
bp SRCoutx x q nIBAin
bp SRCouty y q nIBAin

bp SRMYqx x q nSRMHRa
bp SRMYqy y q nSRMHRa

bp ITMXqx x q nITMX2
bp ITMXqy y q nITMX2

bp ITMYqx x q nITMY2
bp ITMYqy y q nITMY2

bp OMCqx x q nOMC_HROC_refl
bp OMCqy y q nOMC_HROC_refl

bp OFIqx x q nIBAin
bp OFIqy y q nIBAin


"""
add_squeezing="""
sq sqz 0 10 0 nsqz
"""
