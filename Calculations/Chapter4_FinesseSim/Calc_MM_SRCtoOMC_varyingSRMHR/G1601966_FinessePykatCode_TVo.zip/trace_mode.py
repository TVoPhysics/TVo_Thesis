import pykat

def from_cav_to_BS(kat,cavity):
	    
	for cav in kat.getAll(pykat.commands.cavity):
		cav.enabled = False
	
	katcavstr='katcav=kat.'+cavity+'.enabled=True'
	exec(katcavstr)
#	katcav.enabled = True

	out_get = kat.run(getTraceData = True)
	qx = out_get[1][0]['nPRBS'][0]._gauss_param__q
	qy = out_get[1][0]['nPRBS'][1]._gauss_param__q

	return qx, qy
